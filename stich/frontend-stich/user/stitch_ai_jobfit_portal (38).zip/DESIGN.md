---
name: Technical Precision
colors:
  surface: '#0d1322'
  surface-dim: '#0d1322'
  surface-bright: '#333949'
  surface-container-lowest: '#080e1d'
  surface-container-low: '#151b2b'
  surface-container: '#191f2f'
  surface-container-high: '#242a3a'
  surface-container-highest: '#2f3445'
  on-surface: '#dde2f7'
  on-surface-variant: '#c7c4d7'
  inverse-surface: '#dde2f7'
  inverse-on-surface: '#2a3040'
  outline: '#908fa0'
  outline-variant: '#464554'
  surface-tint: '#c0c1ff'
  primary: '#c0c1ff'
  on-primary: '#1000a9'
  primary-container: '#8083ff'
  on-primary-container: '#0d0096'
  inverse-primary: '#494bd6'
  secondary: '#d0bcff'
  on-secondary: '#3c0091'
  secondary-container: '#571bc1'
  on-secondary-container: '#c4abff'
  tertiary: '#89ceff'
  on-tertiary: '#00344d'
  tertiary-container: '#009ada'
  on-tertiary-container: '#002d43'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#07006c'
  on-primary-fixed-variant: '#2f2ebe'
  secondary-fixed: '#e9ddff'
  secondary-fixed-dim: '#d0bcff'
  on-secondary-fixed: '#23005c'
  on-secondary-fixed-variant: '#5516be'
  tertiary-fixed: '#c9e6ff'
  tertiary-fixed-dim: '#89ceff'
  on-tertiary-fixed: '#001e2f'
  on-tertiary-fixed-variant: '#004c6e'
  background: '#0d1322'
  on-background: '#dde2f7'
  surface-variant: '#2f3445'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-md:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  2xl: 64px
  container-max: 1280px
  gutter: 24px
---

## Brand & Style

The design system is engineered for a high-stakes professional environment where data accuracy and career trajectory intersect. The brand personality is **authoritative, analytical, and futuristic**, evoking the feeling of a premium cockpit for career navigation. 

The aesthetic centers on **Technical Precision**, merging a rigorous data-driven layout with atmospheric depth. It utilizes a sophisticated dark mode palette to reduce visual fatigue during deep-focus tasks. Key visual drivers include:
- **Glassmorphism:** To imply transparency in AI decision-making.
- **Luminescent Accents:** To draw the eye to critical success metrics and "Perfect Fit" indicators.
- **Investor-Ready Sophistication:** A balance of dense information density and high-end polish that signals a mature, scalable platform.

## Colors

This design system utilizes a "Deep Space" palette to create a sense of infinite depth and high-tech elegance.

- **Foundational Neutrals:** The background uses a charcoal-black (#080e1d), while primary surfaces use a deep navy (#0d1322). This subtle shift in dark tones provides structure without harsh lines.
- **Electric Accents:** Indigo (#6366f1) serves as the primary action color, while Electric Violet (#8b5cf6) is reserved for AI-augmented insights and "Match Score" highlights.
- **Semantic Signals:** High-contrast white (#f8fafc) is used for primary text to ensure WCAG AAA readability against the dark backdrop. Success states utilize a vibrant teal-cyan to differentiate from the violet/indigo core.

## Typography

The design system relies exclusively on **Inter** to maintain a clean, systematic appearance. 

- **Weight Strategy:** Use Bold (700) and Semi-Bold (600) for data headers to ground the interface. Medium (500) is the standard for interactive labels to ensure they don't "bleed" visually into the dark background.
- **Readability:** On dark surfaces, tracking is slightly increased (+0.01em to +0.05em) for smaller labels to prevent characters from appearing too cramped.
- **Scale:** A tight typographic scale ensures that data-heavy screens remain scannable. `display-lg` is reserved for dashboard hero stats (e.g., your Fit Score), while `body-md` handles the bulk of the descriptive content.

## Layout & Spacing

The design system employs a **4px baseline grid** to achieve technical precision in alignment. 

- **Grid System:** A 12-column fluid grid is used for desktop layouts with a fixed maximum width of 1280px to prevent line lengths from becoming unreadable.
- **Information Density:** For data-rich views (like job listings), a "Compact" spacing model is used (8px-12px internal padding). For marketing or landing pages, "Expressive" spacing (40px-64px) is utilized to allow the glassmorphism effects to breathe.
- **Breakpoints:** 
    - **Desktop:** 12-column, 24px gutters, 40px margins.
    - **Tablet:** 8-column, 16px gutters, 24px margins.
    - **Mobile:** 4-column, 16px gutters, 16px margins.

## Elevation & Depth

Depth is not communicated via traditional drop shadows, but through **Tonal Stacking** and **Backdrop Blurs**.

- **Level 0 (Floor):** The base background (#080e1d).
- **Level 1 (Cards):** Deep navy (#0d1322) with a 15% opacity white inner stroke. This simulates a "glass" edge catching light.
- **Level 2 (Modals/Popovers):** Semi-transparent surfaces (80% opacity) with a `backdrop-filter: blur(12px)`. These elements feature a soft outer glow of the primary indigo color (10% opacity) to suggest they are "powered" or active.
- **Illumination:** Use radial gradients in the background—subtle, large-scale washes of Indigo and Violet—to create a sense of atmospheric light behind the glass cards.

## Shapes

The shape language is **Structured & Modern**. 

- **Primary Radius:** 0.5rem (8px) is the standard for buttons, input fields, and small cards. This provides a professional balance between "friendly" and "technical."
- **Large Components:** Main dashboard containers and glass cards use 1rem (16px) to emphasize the frosted glass aesthetic.
- **Interactive Elements:** Checkboxes use a 4px radius, while status chips use a full pill-shape (999px) to distinguish them from actionable buttons.

## Components

- **Buttons:** 
    - *Primary:* Solid Indigo (#6366f1) with a subtle 20px top-down gradient to #8b5cf6. 
    - *Secondary:* Ghost style with a 1px border of 20% white and a blur effect.
- **Glass Cards:** Must include `backdrop-filter: blur(16px)`, a 1px border at 15% white, and an inner 1px glow on the top edge only.
- **Inputs:** Darker than the surface (#050a15) with a 1px border. On focus, the border transitions to Primary Indigo with a 4px outer glow.
- **AI Fit Score Gauge:** A circular or semi-circular progress bar using a gradient from Indigo to Violet, featuring a "breathing" outer glow animation when the AI is calculating.
- **Status Chips:** Low-opacity backgrounds (10%) with high-opacity text and a small leading "pulse" dot to indicate real-time data.
- **Data Visualization:** Line charts should use "neon" strokes with a soft glow (drop-shadow filter) to stand out against the deep navy grid lines.